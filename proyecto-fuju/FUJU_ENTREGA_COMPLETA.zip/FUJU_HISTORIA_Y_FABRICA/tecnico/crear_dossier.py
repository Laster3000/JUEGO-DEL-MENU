# coding: utf-8
import json, collections
from pathlib import Path
BASE=Path(__file__).resolve().parent.parent
b=json.loads((BASE/'canon/game-bible.json').read_text(encoding='utf8'))
d=json.loads((BASE/'tecnico/dialogues-v1.json').read_text(encoding='utf8'))
# Each hotspot has its own replacement-safe ID. Coordinates defined after scene art.
scene_objects={
'S0101':['paso_de_cebra','escaparate','reloj_municipal','bolsillo_abrigo','pendon'],
'S0102':['reloj_pared','notas_guardia','hoja_humeda','informe','adua'],
'S0103':['moldura','cortina','lampara','espejo','miga','pendon'],
'S0201':['mesa_de_rocas','cuenco_agua','gong_piedra','ubroca'],
'S0202':['arbol_corto','arbol_pesado','arbol_copa','apoyos_puente','fulio'],
'S0203':['plaza','silbatos','fuju','ventanas_minerales'],
'S0301':['billete','aguja','veta_mineral','ventanas_fuju','vera'],
'S0302':['plano','asiento_7','plato','espejo_comedor','bardo','vera'],
'S0303':['baul_lino','baul_cuero','baul_madera','etiquetas','fulio'],
'S0401':['campanas','surco_agua','reloj','tair','vera'],
'S0402':['vidrio','calco','huellas_polvo','espejo_cabina','pendon'],
'S0403':['valvula_a','valvula_b','valvula_c','pulso_fuju','tair'],
'S0501':['arbol_flexible','cinta_viento','maceta','reglamento','juez'],
'S0502':['silbato','argolla','mesa_trabajo','luma','fulio'],
'S0503':['retratos','balcon','campanilla','inscripcion','seron','miga'],
'S0601':['indice','fichero_hechos','fichero_testigos','acta','seron'],
'S0602':['lente_concava','cristal_agua','espejo_apagado','pantalla_sombra','seron'],
'S0603':['mesa_juramento','grabacion_maura','seron','acta','fulio'],
'S0701':['cargos','informe','huellas_elva','acta','testigos','miga'],
'S0702':['aguja_tinta','sello_frio','chicle','ranura_registro','pendon'],
'S0703':['vidrio_de_elva','contrato_fulio','sellos_de_testigos','miga','vera'],
'S0801':['piedra_eco','billete','campana','acta','durmientes','fuju'],
'S0802':['habitacion','puerta_antigua','maura','ridel','memorias'],
'S0803':['declaracion_final','coste_e01','coste_e02','confirmacion','fuju'],
}
assert set(scene_objects)==set(s['id'] for s in b['scenes'])
chars={c['id']:c for c in b['characters']}
ps={s['id']:[p['id'] for p in b['puzzles'] if p['sceneId']==s['id']] for s in b['scenes']}
interactions=[]
for sc in b['scenes']:
 sceneid=sc['id'];klist=scene_objects[sceneid]
 hs=[]
 for idx,key in enumerate(klist):
  pk=ps[sceneid] if idx<3 else []
  hs.append({'id':sceneid+'_H'+str(idx+1).zfill(2),'objectKey':key,'type':'npc' if key in chars else 'prop','verbs':['mirar','usar','hablar'] if key in chars else ['mirar','usar','combinar'],'puzzleRefs':pk,'spriteAsset':'scenes/'+sceneid.lower()+'/hotspots/'+key+'.png','shapeAsset':'scenes/'+sceneid.lower()+'/hotspots/'+key+'.json','clickRegion':'TO_AUTHOR_AFTER_BACKGROUND_LOCK','defaultLine':'Examinar '+key.replace('_',' ')+'.','stateVariants':['base','interactuado'],'zIndex':10+idx})
 interactions.append({'sceneId':sceneid,'requiredFlagsOnEnter':sc['entryConditions'],'hotspots':hs,'musicCue':'music/ch'+sc['chapterId'][-2:]+'.ogg','ambienceCue':'ambience/'+sceneid+'.ogg','exits':[{'id':sceneid+'_EXIT_NEXT','condition':'AUTHOR_CHAPTER_TRANSITION_GATE_FROM_PUZZLE_MATRIX','targetScene':'DERIVE_NEXT_FROM_CANON_ORDER'}],'focusOrder':[h['id'] for h in hs],'responsiveSafe':True})
interaction_doc={'schemaVersion':'1.0.0','status':'PRODUCTION_AUTHORING_MAP_NOT_RENDERED','hotspotCoordsPendingArt':True,'scenes':interactions}
(BASE/'tecnico/scenes-interactions.json').write_text(json.dumps(interaction_doc,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
# Human readable, complete structured dossier spoilers intentional.
lines=['# DOSSIER DE FABRICACIÓN - CANON COMPLETO','', '**SPOILERS. Documento exclusivo de producción.**','', 'Fuente de verdad ejecutable: `canon/game-bible.json`, `tecnico/scenes-interactions.json`, `tecnico/dialogues-v1.json`. Este dossier es una lectura humana generada de esas fuentes.','', '## Reglas de mundo y coherencia','']
for i,rule in enumerate(b['worldRules'],1):lines.append(f'{i}. {rule}')
lines+=['','## Reparto y voces','']
for c in b['characters']:
 lines+=['### '+c['name']+' (`'+c['id']+'`)','','**Rol:** '+c['role']+'. '+c['voice'],'',c['arc'],'']
lines+=['## Inventario persistente','']
for item in b['items']:
 lines+=['- **'+item['name']+'** (`'+item['id']+'`): adquirido '+item['obtainedChapter']+', usos '+item['uses']+'. '+item['description']]
lines+=['','## Guion completo de capítulos, escenas y puzles','']
for chap in b['chapters']:
 lines+=['## '+chap['id']+' · '+chap['title'],'',chap['premise'],'']
 for scid in chap['scenes']:
  sc=next(v for v in b['scenes'] if v['id']==scid)
  iscene=next(v for v in interactions if v['sceneId']==scid)
  lines+=['### '+scid+' · '+sc['title'],'','**Lugar:** '+sc['location'],'' ,sc['dramaticIntent'],'', '**Entrada:** '+(', '.join(sc['entryConditions']) if sc['entryConditions'] else 'Libre/previa escena')+'.','', '**Hotspots / capas intercambiables:** '+', '.join(h['objectKey'] for h in iscene['hotspots'])+'.','']
  for p in [x for x in b['puzzles'] if x['sceneId']==scid]:
   lines+=['**'+p['id']+' — '+p['title']+'** · '+p['category'], '', '- Objetivo: '+p['objective'], '- Solución canónica: '+p['canonicalActions'], '- Condición: '+p['successCondition'], '- Recuperación: '+p['softlockProtection'], '- Pistas graduadas:']
   for j,hint in enumerate(p['hints'],1):lines.append(f'  {j}. {hint}')
   lines+=['']
  n=next(v for v in d['nodes'] if v['sceneId']==scid and v['autoStart'])
  lines+=['**Diálogo inicial authored (base; expandir para producto final):**','']
  for ln in n['lines']:lines.append('> '+ln['speaker']+': '+ln['text'])
  lines.append('')
lines+=['## Epílogos y coste (SPOILER)','']
for e in b['endings']:lines+=['- **'+e['id']+': '+e['name']+'**. '+e['cost']]
lines+=['','## Cambios de arte y narrativa','', 'Los IDs de escena, hotspot y personaje son estables. Las capas de fondo, props, iluminación, personajes, texto y música pueden revisarse sin cambiar la lógica ni los saves. Las formas poligonales de clic deben trazarse sobre cada fondo definitivo y verificarse con teclado.','', '## Limitación declarada', '', 'Los 48 nodos de `dialogues-v1.json` constituyen una base autoral comprobable; NO son todavía el guion de diálogos ramificados completos ni incluyen actuación de voz. La fábrica debe ampliar los nodos y verificar cada rama antes de M1/M2.','']
(BASE/'tecnico/DOSSIER-CANON-COMPLETO.md').write_text('\n'.join(lines),encoding='utf8')
print(json.dumps({'sceneHotspots':sum(len(s['hotspots']) for s in interactions),'dossierWords':len(('\n'.join(lines)).split())},ensure_ascii=False))
