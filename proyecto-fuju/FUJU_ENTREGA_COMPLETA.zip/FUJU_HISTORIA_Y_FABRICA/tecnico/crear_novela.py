# coding:utf-8
from pathlib import Path
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
import re, hashlib
BASE=Path('/mnt/data/FUJU_HISTORIA_Y_FABRICA')
N=BASE/'novela'; OUT=BASE/'exportaciones'
markers={
'01':'Al atardecer, cuando le dieron el alta',
'02':'Encontró a Fulio Tesp sentado',
'03':'El comedor era una sala ovalada',
'04':'La cabina de espejos estaba cerrada',
'05':'El taller de Luma olía',
'06':'La torre tenía tres cristales',
'07':'El tribunal estaba presidido',
'08':'La mesa comenzó a vibrar',
}
chapters=[]
for i in range(1,9):
 s=f'{i:02d}'; main=(N/f'{s}.md').read_text(encoding='utf8').strip();extra=(N/f'{s}-ampliacion.md').read_text(encoding='utf8').strip()
 assert main.count(markers[s])==1,(s,main.count(markers[s]))
 pos=main.index(markers[s]); assert pos>0
 main=main[:pos]+extra+'\n\n'+main[pos:]
 chapters.append(main)
combined='# EL ANDÉN DE LOS NOMBRES QUE FALTAN\n\n'+'\n\n'.join(chapters)+'\n'
(N/'NOVELA-COMPLETA.md').write_text(combined,encoding='utf8')
wordcount=len(re.findall(r'\b[\wÁÉÍÓÚÜÑáéíóúüñ]+\b',combined))
print('wordcount',wordcount)

def format_file(font_size=13.5,line_spacing=1.27):
 d=Document(); s=d.sections[0];s.page_width=Cm(10.5);s.page_height=Cm(14.8);s.top_margin=Cm(1.10);s.bottom_margin=Cm(1.18);s.left_margin=Cm(1.18);s.right_margin=Cm(1.18);s.header_distance=Cm(.4);s.footer_distance=Cm(.60)
 st=d.styles['Normal'];st.font.name='Liberation Serif';st.font.size=Pt(font_size);st.font.color.rgb=RGBColor(30,27,25)
 pf=st.paragraph_format;pf.line_spacing=line_spacing;pf.space_after=Pt(0);pf.space_before=Pt(0);pf.first_line_indent=Cm(.32)
 title=d.styles.add_style('TituloLibro',WD_STYLE_TYPE.PARAGRAPH); title.base_style=st;title.font.name='Liberation Serif';title.font.size=Pt(22);title.font.bold=True;title.font.color.rgb=RGBColor(44,43,48)
 title.paragraph_format.space_before=Pt(22);title.paragraph_format.space_after=Pt(20);title.paragraph_format.first_line_indent=Cm(0)
 chst=d.styles.add_style('CapituloLibro',WD_STYLE_TYPE.PARAGRAPH);chst.base_style=st;chst.font.name='Liberation Serif';chst.font.size=Pt(18);chst.font.bold=False;chst.font.color.rgb=RGBColor(54,48,54)
 chst.paragraph_format.space_before=Pt(20);chst.paragraph_format.space_after=Pt(28);chst.paragraph_format.first_line_indent=Cm(0);chst.paragraph_format.keep_with_next=True
 # cover
 p=d.add_paragraph(style='TituloLibro');p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.add_run('EL ANDÉN\nDE LOS NOMBRES\nQUE FALTAN')
 p=d.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.first_line_indent=Cm(0);p.paragraph_format.space_before=Pt(20);p.add_run('Una novela de misterio y fantasía').italic=True
 d.add_page_break()
 p=d.add_paragraph();p.paragraph_format.first_line_indent=Cm(0);p.paragraph_format.space_before=Pt(35);r=p.add_run('Para quienes alguna vez han echado de menos algo que nadie más recordaba.');r.italic=True
 d.add_page_break()
 for chapter in chapters:
  chunks=[x.strip() for x in chapter.split('\n\n') if x.strip()]
  heading=chunks.pop(0);assert heading.startswith('## Capítulo')
  h=d.add_paragraph(heading.replace('## ','').strip(),style='CapituloLibro');h.paragraph_format.page_break_before=True
  for j,text in enumerate(chunks):
   p=d.add_paragraph(style='Normal');p.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY if not text.startswith('—') else WD_ALIGN_PARAGRAPH.LEFT
   if j==0 or text.startswith('—'):p.paragraph_format.first_line_indent=Cm(0)
   # Avoid widows/orphans while not leaving entire body paragraphs together.
   pPr=p._p.get_or_add_pPr();w=OxmlElement('w:widowControl');w.set(qn('w:val'),'1');pPr.append(w)
   p.add_run(text)
 # footer with page field
 footer=s.footer.paragraphs[0]; footer.alignment=WD_ALIGN_PARAGRAPH.CENTER;footer.paragraph_format.first_line_indent=Cm(0)
 run=footer.add_run();run.font.size=Pt(8); run.font.color.rgb=RGBColor(120,115,115)
 fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');run._r.addnext(fld)
 d.core_properties.title='El andén de los nombres que faltan';d.core_properties.subject='Novela de misterio fantástico';d.core_properties.author='Obra original desarrollada para el proyecto AUTOFABRICADOR'
 path=OUT/'EL_ANDEN_NOVELA.docx';d.save(path);print(path)
format_file()
