# coding:utf-8
from pathlib import Path
import json, fitz, hashlib, re, collections
BASE=Path(__file__).resolve().parent.parent
b=json.loads((BASE/'canon/game-bible.json').read_text(encoding='utf8'))
d=json.loads((BASE/'tecnico/dialogues-v1.json').read_text(encoding='utf8'))
i=json.loads((BASE/'tecnico/scenes-interactions.json').read_text(encoding='utf8'))
ch=b['chapters']; sc=b['scenes']; pu=b['puzzles']; chars=b['characters']; items=b['items']
checks={
 'eight_chapters':len(ch)==8,
 'twentyfour_scenes':len(sc)==24,
 'nineteen_puzzles':len(pu)==19,
 'two_or_three_puzzles_per_chapter':all(2<=sum(p['chapterId']==c['id'] for p in pu)<=3 for c in ch),
 'three_hints_per_puzzle':all(len(p['hints'])==3 and all(p['hints']) for p in pu),
 'scene_refs_exist':all(p['sceneId'] in {s['id'] for s in sc} for p in pu),
 'unique_scene_puzzle_ids':len({s['id'] for s in sc})==len(sc) and len({p['id'] for p in pu})==len(pu),
 'puzzle_success_flags_exist':all(p['successCondition'].startswith('flag:') and p['successCondition'][5:] in b['stateFlags'] for p in pu),
 'scene_entry_flags_exist':all(v.startswith('flag:') and v[5:] in b['stateFlags'] for s in sc for v in s['entryConditions']),
 'chapters_have_scenes':all(len(c['scenes'])==3 and all(sid in {s['id'] for s in sc} for sid in c['scenes']) for c in ch),
 'all_scenes_have_hotspots':len(i['scenes'])==len(sc) and all(len(x['hotspots'])>=4 for x in i['scenes']),
 'unique_hotspots':len({h['id'] for s in i['scenes'] for h in s['hotspots']})==sum(len(s['hotspots']) for s in i['scenes']),
 'dialogue_intro_per_scene':all(sum(n['sceneId']==s['id'] and n['autoStart'] for n in d['nodes'])==1 for s in sc),
 'dialogue_refs_valid':all(n['sceneId'] in {s['id'] for s in sc} for n in d['nodes']),
 'characters_nonempty':len(chars)>=10 and all(c['voice'] and c['arc'] for c in chars),
 'important_names':{'Fuju','Fulio Tesp','Serón','Miga','Pendón','Ubroca'}.issubset({x['name'] for x in chars}),
 'items_nonconsumable':len(items)>=10 and all(x['canLose']==False for x in items),
 'ends_two':len(b['endings'])==2,
 'novel_eight_separated_chapters':sum(x.startswith('## Capítulo ') for x in (BASE/'novela/NOVELA-COMPLETA.md').read_text(encoding='utf8').splitlines())==8,
}
noveltext=(BASE/'novela/NOVELA-COMPLETA.md').read_text(encoding='utf8')
novelwords=len(re.findall(r'\b[\wáéíóúÁÉÍÓÚñÑüÜ]+\b',noveltext))
pdf=fitz.open(BASE/'exportaciones/EL_ANDEN_NOVELA.pdf')
page_count=len(pdf)
checks['pocket_edition_at_least_200_pages']=page_count>=200
bad=[];blank=[]
for j,p in enumerate(pdf):
 words=p.get_text('words')
 if not words:blank.append(j+1)
 for x0,y0,x1,y1,*rest in words:
  if x0<-.1 or y0<-.1 or x1>p.rect.width+.1 or y1>p.rect.height+.1:bad.append(j+1);break
checks['novel_text_within_page_bounds']=not bad
checks['novel_no_blank_pages']=not blank
result={'packageId':'FUJU-EL-ANDEN-20261108-v1','verificationType':'STATIC_CONTENT_AND_PDF_LAYOUT_ONLY','status':'PASS_STATIC' if all(checks.values()) else 'FAILED_STATIC','checks':checks,'metrics':{'novelWords':novelwords,'pocketPages':page_count,'pageSize': 'A6 105 x 148 mm','chapters':len(ch),'scenes':len(sc),'puzzles':len(pu),'hints':sum(len(p['hints']) for p in pu),'characters':len(chars),'items':len(items),'dialogueNodes':len(d['nodes']),'authorLines':sum(len(n['lines']) for n in d['nodes']),'hotspots':sum(len(s['hotspots']) for s in i['scenes'])},'pdfOvershootPages':bad,'blankPages':blank,'explicitLimits':{'functionalGameBuilt':False,'e2eGameTested':False,'gameInstalled':False,'dialogueNodesCompleteForRelease':False,'artAssetsGenerated':False,'measuredGameDuration':False}}
(BASE/'qa/CONTENIDO-RESULTADOS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(result,ensure_ascii=False,indent=2))
if not all(checks.values()): raise SystemExit(1)
