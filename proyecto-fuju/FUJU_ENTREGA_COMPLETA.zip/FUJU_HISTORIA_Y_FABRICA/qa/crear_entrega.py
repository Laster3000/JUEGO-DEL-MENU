# coding:utf-8
from pathlib import Path
import hashlib,json,zipfile,shutil,datetime
BASE=Path(__file__).resolve().parent.parent
OUT=Path('/mnt/data')
# Deliverables do not include raster QA intermediates.
files=sorted(p for p in BASE.rglob('*') if p.is_file() and p.name!='MANIFEST-SHA256.json' and '__pycache__' not in str(p))
manifest={'packageId':'FUJU-EL-ANDEN-20261108-v1','kind':'STORY_AND_FACTORY_HANDOFF','createdDate':'2026-11-08','sourceRepoInspectedReadOnly':'Laster3000/AUTOFABRICADOR','notInstalled':True,'notExecutableGame':True,'digestAlgorithm':'SHA-256','files':[]}
for p in files:
 bb=p.read_bytes(); manifest['files'].append({'path':str(p.relative_to(BASE)).replace('\\','/'),'sizeBytes':len(bb),'sha256':hashlib.sha256(bb).hexdigest()})
(BASE/'MANIFEST-SHA256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
zip_file=OUT/'FUJU_ENTREGA_COMPLETA.zip'
with zipfile.ZipFile(zip_file,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for p in sorted(BASE.rglob('*')):
  if p.is_file(): z.write(p,'FUJU_HISTORIA_Y_FABRICA/'+str(p.relative_to(BASE)).replace('\\','/'))
with zipfile.ZipFile(zip_file) as z:
 fail=z.testzip(); assert fail is None,fail
 for ent in manifest['files']:
  contents=z.read('FUJU_HISTORIA_Y_FABRICA/'+ent['path']);assert hashlib.sha256(contents).hexdigest()==ent['sha256']
shortcuts={
 'FUJU_NOVELA_205_PAGINAS.pdf':'exportaciones/EL_ANDEN_NOVELA.pdf',
 'FUJU_NOVELA_EDITABLE.docx':'exportaciones/EL_ANDEN_NOVELA.docx',
 'FUJU_NOVELA_LECTOR.epub':'exportaciones/EL_ANDEN_NOVELA.epub',
 'FUJU_HANDOFF_AUTOFABRICA.pdf':'exportaciones/HANDOFF_AUTOFABRICA.pdf',
 'FUJU_HANDOFF_AUTOFABRICA.docx':'exportaciones/HANDOFF_AUTOFABRICA.docx',
 'FUJU_HANDOFF_AUTOFABRICA.md':'tecnico/HANDOFF-AUTOFABRICA.md',
}
for name,src in shortcuts.items():shutil.copy2(BASE/src,OUT/name)
print(json.dumps({'package':str(zip_file),'zipSha256':hashlib.sha256(zip_file.read_bytes()).hexdigest(),'fileCount':len(manifest['files']),'bytesZip':zip_file.stat().st_size,'shortcuts':{k:(OUT/k).stat().st_size for k in shortcuts}},ensure_ascii=False,indent=2))
