const starts = [0, 2, 4, 7, 10, 12, 15, 17];
const lengths = [2, 2, 3, 3, 2, 3, 2, 2];

export function requiredMask(chapter) {
  const start = starts[chapter - 1];
  const length = lengths[chapter - 1];
  return ((1 << length) - 1) << start;
}
