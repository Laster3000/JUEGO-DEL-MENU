import { requiredMask } from './rules.js';

export function chapterCleared(chapter, solvedMask) {
  if (!Number.isInteger(chapter) || chapter < 1 || chapter > 8 || !Number.isInteger(solvedMask) || solvedMask < 0) return false;
  const required = requiredMask(chapter);
  return (required & solvedMask) === required;
}
