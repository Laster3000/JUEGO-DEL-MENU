AUTOFABRICADOR portable offline project.
Open index.html in a browser; no npm installation or network required.
All generated source first passed original WASI owner tests.
The browser controller and stylesheet are first-party templates.
Do not execute model-authored npm lifecycle scripts or Node shell.
