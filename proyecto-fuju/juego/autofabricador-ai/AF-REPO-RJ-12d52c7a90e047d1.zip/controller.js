"use strict";
document.getElementById("run").addEventListener("click",()=>{
 const target=document.getElementById("result");
 const state=document.getElementById("status");
 try{
  const params=Array.from({length:2},(_,i)=>JSON.parse(document.querySelector("[data-argument=\""+i+"\"]").value));
  const value=chapterCleared(...params);
  target.textContent=typeof value==="string"?value:JSON.stringify(value);
  state.textContent="Cálculo completado localmente";
 }catch(error){target.textContent="Error de entrada";state.textContent="Revisa los argumentos JSON";}
});
