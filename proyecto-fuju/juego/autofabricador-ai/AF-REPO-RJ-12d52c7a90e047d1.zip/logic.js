var AFProject = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // af-source:C:\Users\laste\AppData\Local\Temp\af-repo-graph-p0ph6qt9\src\index.js
  var index_exports = {};
  __export(index_exports, {
    chapterCleared: () => chapterCleared
  });

  // af-source:C:\Users\laste\AppData\Local\Temp\af-repo-graph-p0ph6qt9\src\rules.js
  var starts = [0, 2, 4, 7, 10, 12, 15, 17];
  var lengths = [2, 2, 3, 3, 2, 3, 2, 2];
  function requiredMask(chapter) {
    const start = starts[chapter - 1];
    const length = lengths[chapter - 1];
    return (1 << length) - 1 << start;
  }

  // af-source:C:\Users\laste\AppData\Local\Temp\af-repo-graph-p0ph6qt9\src\index.js
  function chapterCleared(chapter, solvedMask) {
    if (!Number.isInteger(chapter) || chapter < 1 || chapter > 8 || !Number.isInteger(solvedMask) || solvedMask < 0) return false;
    const required = requiredMask(chapter);
    return (required & solvedMask) === required;
  }
  return __toCommonJS(index_exports);
})();

;var chapterCleared=AFProject.chapterCleared;
